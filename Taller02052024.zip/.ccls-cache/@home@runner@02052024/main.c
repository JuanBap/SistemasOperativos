/********************
* Autor: 





*********************/

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <string>

int main (int argc, char* argv[]){

  printf("Hola Clases de Sistemas Operativos\n");

  
  return 0;
}