/********************
* Autores: Juan Pablo Cañón Contreras y Harry Esteban Sánchez Guevara
* Fecha: 02/05/2024
* Sistemas Operativos
* Tema: Captura de Argumentos de Entrada
* Se van a capturar los siguientes argumentos de entrada:
* $ ./ejecutable -z zvalor -x xvalor -a nArchivo
*******************